// src/pages/ProfilePage.jsx
import Profile from '../components/auth/Profile';

function ProfilePage() {
  return <Profile />;
}

export default ProfilePage;