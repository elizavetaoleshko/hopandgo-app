# Destination Images

This directory contains images for each destination in the Hop&Go application.

Images will be automatically downloaded and saved here when the application runs.

Structure:
- fontainebleau.jpg - Château de Fontainebleau
- provins.jpg - Medieval city of Provins
- chantilly.jpg - Château de Chantilly
- senlis.jpg - Historic Senlis
- giverny.jpg - Monet's Gardens
- vaux-le-vicomte.jpg - Château de Vaux-le-Vicomte
- auvers-sur-oise.jpg - Van Gogh's Auvers
- paris.jpg - Paris cityscape